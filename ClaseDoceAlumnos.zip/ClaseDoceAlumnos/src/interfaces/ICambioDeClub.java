
package interfaces;


public interface ICambioDeClub {
    
    
    void Transferencia();
    
    
}
