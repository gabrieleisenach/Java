
package interfaces;

//Modificador acceso interface nombreInterface
public interface ICasoImpresora {
    
    
    //Metodos 
    
    
    //No llevan modificador de acceso 
    //Por defecto son todos abstarctos y publicos 
    
    
    
    String Impresion();
    
    
    
}
